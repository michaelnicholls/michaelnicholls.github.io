sap.ui.define([
    
], function() {
    'use strict';

    return {
        
        show_output: function(oEvent) {
             var parguid = this.getView().getBindingContext().getObject().Parguid;
          var oCrossAppNav = sap.ushell.Container.getService("Navigation");
            oCrossAppNav.navigate({
                target: {semanticObject: "zparams",action:"showall"},
                params: {"Parguid" : parguid}
            });

        },
        refresh: function(oEvent) {
            location.reload(true);
        }
    }
});
